library(testthat)
library(anomalize)
library(dplyr)
library(ggplot2)
library(tibble)

# set_time_scale_template(time_scale_template())

test_check("anomalize")
