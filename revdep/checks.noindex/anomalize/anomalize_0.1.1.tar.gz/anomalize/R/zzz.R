
# By default set time_scale_template_options to time_scale_template()
.onLoad = function(libname, pkgname) {
    options(
        time_scale_template = time_scale_template()
    )
}
