library(testthat)
library(tsbox)

test_check("tsbox")
